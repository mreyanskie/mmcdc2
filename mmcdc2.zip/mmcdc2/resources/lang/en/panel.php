<?php

return [
    'site_title' => 'MMC&DC',
];
