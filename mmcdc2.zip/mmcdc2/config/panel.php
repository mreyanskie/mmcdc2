<?php

return [
    'date_format'         => 'm/d/Y',
    'time_format'         => 'H:i',
    'primary_language'    => 'en',
    'available_languages' => [
        'en' => 'English',
    ],
    'registration_default_role' => '2',
];
