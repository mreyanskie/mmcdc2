<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.edit')); ?> <?php echo e(trans('cruds.patient.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.patients.update", [$patient->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group <?php echo e($errors->has('first_name') ? 'has-error' : ''); ?>">
                <label for="first_name"><?php echo e(trans('cruds.patient.fields.first_name')); ?>*</label>
                <input type="text" id="first_name" name="first_name" class="form-control" value="<?php echo e(old('first_name', isset($patient) ? $patient->first_name : '')); ?>" required>
                <?php if($errors->has('first_name')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('first_name')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.patient.fields.first_name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('last_name') ? 'has-error' : ''); ?>">
                <label for="last_name"><?php echo e(trans('cruds.patient.fields.last_name')); ?>*</label>
                <input type="text" id="last_name" name="last_name" class="form-control" value="<?php echo e(old('last_name', isset($patient) ? $patient->last_name : '')); ?>" required>
                <?php if($errors->has('last_name')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('last_name')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.patient.fields.last_name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('contact') ? 'has-error' : ''); ?>">
                <label for="contact"><?php echo e(trans('cruds.patient.fields.contact')); ?></label>
                <input type="text" id="contact" name="contact" class="form-control" value="<?php echo e(old('contact', isset($patient) ? $patient->contact : '')); ?>">
                <?php if($errors->has('contact')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('contact')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.patient.fields.contact_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                <label for="email"><?php echo e(trans('cruds.patient.fields.email')); ?>*</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo e(old('email', isset($patient) ? $patient->email : '')); ?>" required>
                <?php if($errors->has('email')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('email')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.patient.fields.email_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('gender') ? 'has-error' : ''); ?>">
                <label for="gender"><?php echo e(trans('cruds.patient.fields.gender')); ?>*</label>
                <select id="gender" name="gender" class="form-control" required>
                    <option value="" disabled <?php echo e(old('gender', null) === null ? 'selected' : ''); ?>><?php echo e(trans('global.pleaseSelect')); ?></option>
                    <?php $__currentLoopData = App\Patient::GENDER_SELECT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(old('gender', $patient->gender) === (string)$key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('gender')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('gender')); ?>

                    </em>
                <?php endif; ?>
            </div>
            <div class="form-group <?php echo e($errors->has('diagnosis') ? 'has-error' : ''); ?>">
                <label for="diagnosis"><?php echo e(trans('cruds.patient.fields.diagnosis')); ?></label>
                <textarea id="diagnosis" name="diagnosis" class="form-control "><?php echo e(old('diagnosis', isset($patient) ? $patient->diagnosis : '')); ?></textarea>
                <?php if($errors->has('diagnosis')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('diagnosis')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.patient.fields.diagnosis_helper')); ?>

                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mmcdc2\resources\views/admin/patients/edit.blade.php ENDPATH**/ ?>