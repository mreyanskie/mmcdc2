<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.userAlert.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.user-alerts.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('alert_text') ? 'has-error' : ''); ?>">
                <label for="alert_text"><?php echo e(trans('cruds.userAlert.fields.alert_text')); ?>*</label>
                <input type="text" id="alert_text" name="alert_text" class="form-control" value="<?php echo e(old('alert_text', isset($userAlert) ? $userAlert->alert_text : '')); ?>" required>
                <?php if($errors->has('alert_text')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('alert_text')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.userAlert.fields.alert_text_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('alert_link') ? 'has-error' : ''); ?>">
                <label for="alert_link"><?php echo e(trans('cruds.userAlert.fields.alert_link')); ?></label>
                <input type="text" id="alert_link" name="alert_link" class="form-control" value="<?php echo e(old('alert_link', isset($userAlert) ? $userAlert->alert_link : '')); ?>">
                <?php if($errors->has('alert_link')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('alert_link')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.userAlert.fields.alert_link_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('users') ? 'has-error' : ''); ?>">
                <label for="user"><?php echo e(trans('cruds.userAlert.fields.user')); ?>

                    <span class="btn btn-info btn-xs select-all"><?php echo e(trans('global.select_all')); ?></span>
                    <span class="btn btn-info btn-xs deselect-all"><?php echo e(trans('global.deselect_all')); ?></span></label>
                <select name="users[]" id="users" class="form-control select2" multiple="multiple">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((in_array($id, old('users', [])) || isset($userAlert) && $userAlert->users->contains($id)) ? 'selected' : ''); ?>><?php echo e($user); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->has('users')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('users')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.userAlert.fields.user_helper')); ?>

                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mmcdc2\resources\views/admin/userAlerts/create.blade.php ENDPATH**/ ?>