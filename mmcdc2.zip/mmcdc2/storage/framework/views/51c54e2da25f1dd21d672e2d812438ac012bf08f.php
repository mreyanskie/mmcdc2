<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.create')); ?> <?php echo e(trans('cruds.service.title_singular')); ?>

    </div>

    <div class="card-body">
        <form action="<?php echo e(route("admin.services.store")); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group <?php echo e($errors->has('service_name') ? 'has-error' : ''); ?>">
                <label for="service_name"><?php echo e(trans('cruds.service.fields.service_name')); ?>*</label>
                <input type="text" id="service_name" name="service_name" class="form-control" value="<?php echo e(old('service_name', isset($service) ? $service->service_name : '')); ?>" required>
                <?php if($errors->has('service_name')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('service_name')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.service.fields.service_name_helper')); ?>

                </p>
            </div>
            <div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
                <label for="price"><?php echo e(trans('cruds.service.fields.price')); ?></label>
                <input type="number" id="price" name="price" class="form-control" value="<?php echo e(old('price', isset($service) ? $service->price : '')); ?>" step="0.01">
                <?php if($errors->has('price')): ?>
                    <em class="invalid-feedback">
                        <?php echo e($errors->first('price')); ?>

                    </em>
                <?php endif; ?>
                <p class="helper-block">
                    <?php echo e(trans('cruds.service.fields.price_helper')); ?>

                </p>
            </div>
            <div>
                <input class="btn btn-danger" type="submit" value="<?php echo e(trans('global.save')); ?>">
            </div>
        </form>


    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mmcdc2\resources\views/admin/services/create.blade.php ENDPATH**/ ?>