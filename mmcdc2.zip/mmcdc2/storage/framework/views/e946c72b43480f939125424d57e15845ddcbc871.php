<?php $__env->startSection('content'); ?>
<h3 class="page-title"><?php echo e(trans('global.systemCalendar')); ?></h3>
<div class="card">
    <div class="card-header">
        <?php echo e(trans('global.systemCalendar')); ?>

    </div>

    <div class="card-body">
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css' />

        <div id='calendar'></div>


    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
##parent-placeholder-16728d18790deb58b3b8c1df74f06e536b532695##
<script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.js'></script>
<script>
    $(document).ready(function () {
            events=<?php echo json_encode($events); ?>;
            $('#calendar').fullCalendar({
               
                events: events,
                defaultView: 'agendaDay',
                //hide weekends
                hiddenDays: [0, 6],
                //header buttons and arrangement
                header: { left: 'month, agendaWeek, agendaDay, list',
                          center:'title',
                          right: 'today, prevYear, prev, next, nextYear'
                        },
                //change button text for prev and next
                buttonText: {
                    prevYear: new moment().year() - 1,
                    nextYear: new moment().year() + 1
                },
                viewRender: function(view) {
                    var y = moment($('#calendar').fullCalendar('getDate')).year();
                    $('.fc-prevYear-button').text(y-1);
                    $('.fc-nextYear-button').text(y+1);
                },
                allDaySlot: false,
                minTime: '08:00',
                maxTime: '18:00',
                
            })
        });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\mmcdc2\resources\views/admin/calendar/calendar.blade.php ENDPATH**/ ?>